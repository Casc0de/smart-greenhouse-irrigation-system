from datetime import datetime, timezone
import json

class DataFilter:
    def __init__(self, tank_data_queue, pressure_data_queue, db_queue, thresholds):
        self.tank_data_queue = tank_data_queue
        self.pressure_data_queue = pressure_data_queue

        self.db_queue = db_queue
        self.thresholds = thresholds  # Diccionario con los umbrales para cada tipo de dato
        self.last_values = {}  # Para almacenar los últimos valores recibidos

        self.tank_to_db = {}

    def is_relevant(self, type, value):
        
        print(f"[DATA_filter]")
        print(f" tipo: {type} \n valor: {value}")
        print(f" umbral: {self.thresholds[type]} \n ultimo valor: {self.last_values.get(type, 'N/A')}")
        if type not in self.last_values:
            self.last_values[type] = value
            return True  # Primer dato, siempre pasa el filtro
        

        if abs(value - self.last_values[type]) >= self.thresholds[type]:
            self.last_values[type] = value
            print("Dato relevante. Procede a enviarse a la BD")
            return True  # El dato pasa el filtro
        print("Dato no relevante. No se envía a la BD")
        return False  # El dato no pasa el filtro

    def get_timestamp_utc(self):
        # Normalizar/convertir el campo 'tiempo' a un datetime con zona UTC
        raw_time = datetime.now(timezone.utc)
        if isinstance(raw_time, str):
            try:
                dt = datetime.fromisoformat(raw_time)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                else:
                    dt = dt.astimezone(timezone.utc)
            except Exception:
                dt = datetime.now(timezone.utc)
        elif isinstance(raw_time, datetime):
            dt = raw_time.astimezone(timezone.utc) if raw_time.tzinfo else raw_time.replace(tzinfo=timezone.utc)
        else:
            dt = datetime.now(timezone.utc)

        return dt
    
    async def tank_processor(self):
        while True:
            tank = await self.tank_data_queue.get()     # Se obtiene el mensaje del tanque: objeto MQTT
            tank_decoded = tank.payload.decode()        # Decodificar el payload: objeto --> string
            tank_dic = json.loads(tank_decoded)        # Convertir string (con estructura de JSON) a diccionario
            tank_level = tank_dic["nivel"]             # Obtener el nivel del tanque del diccionario
            tank_tipo = tank_dic["tipo"]
            print(f"Procesando mensaje de tanque: {tank_dic}, tipo de dato: {type(tank_dic)}")
            # Filtrar mensaje de tanque ------------------------
            if self.is_relevant(tank_tipo, tank_level):
                
                tank_dic["tiempo"] = self.get_timestamp_utc()
                print(f"Tiempo es {tank_dic['tiempo']}, tipo es {type(tank_dic['tiempo'])}")

                self.tank_to_db = {"tiempo": tank_dic["tiempo"],
                                   "tipoFertilizante": tank_dic["tipoFertilizante"],
                                   "nivel": tank_dic["nivel"],
                                   "collection": "tank_levels"}

                await self.db_queue.put(self.tank_to_db)      # Se envía el diccionario al queue de la base de datos
            else:
                print(f"Mensaje de tanque descartado por el filtro: {tank_dic}")

    async def pressure_processor(self):
        while True:
            pressure = await self.pressure_data_queue.get()
            # Procesar mensaje de manómetro
            print(f"Procesando mensaje de manómetro: {pressure}")