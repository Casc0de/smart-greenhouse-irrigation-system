import asyncio
import os
import sys
import aiomqtt


from serial_listener import SerialListener
from mqtt_listener import MQTTListener
from data_filter import DataFilter
from database_writer import DatabaseWriter

async def main():
    # queues para la comunicación entre tareas ------------------------
    tank_data_queue = asyncio.Queue()
    pressure_data_queue = asyncio.Queue()
    #self.environment_data_queue = asyncio.Queue()
    #self.soil_data_queue = asyncio.Queue()

    db_queue = asyncio.Queue()
    
    # Inicializar componentes asíncronos -------------------------------
    serial_listener = SerialListener(puerto="COM5", baudrate=57600)
    mqtt_listener = MQTTListener(tank_data_queue, pressure_data_queue)
    data_filter = DataFilter(tank_data_queue, pressure_data_queue, db_queue, thresholds={
        "tanque": 5,      # Umbral para nivel de tanque
        "manometro": 2,   # Umbral para presión del manómetro
        "bomba": 1        # Umbral para estado de la bomba
    })
    database_writer = DatabaseWriter(db_queue)

    # Tareas concurrentes -------------------------------------
    # Conectarse al broker mqtt
    async with aiomqtt.Client(hostname="127.0.0.1", port=1883) as client:
        print("Conectado al broker MQTT")
        # Ejecutar las tareas concurrentes
        await asyncio.gather(
            serial_listener.recibir_datos_arduino(client),
            mqtt_listener.recibir_dato(client),
            data_filter.tank_processor(),
            data_filter.pressure_processor(),
            database_writer.start()
        )

if __name__ == "__main__":
    if sys.platform.lower() == "win32" or os.name.lower() == "nt":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())