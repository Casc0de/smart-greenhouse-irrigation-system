import asyncio
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient

class DatabaseWriter:
    def __init__(self, db_queue, mongo_uri="mongodb://admin:6381#Spiderman@127.0.0.1:27017", 
                 db_name="invernadero"):
        self.mongo_uri = mongo_uri
        self.db_name = db_name
        self.db_queue = db_queue

    async def start(self):
        self.client = AsyncIOMotorClient(self.mongo_uri)
        self.db = self.client[self.db_name]
        self.collections = {
            "tank_levels": self.db["tank_levels"],
            "pressure_readings": self.db["pressure_readings"]
        }

        while True:
            data = await self.db_queue.get()
            await self.write_to_db(data)
            

    async def write_to_db(self, data):
        
        collection_name = data["collection"]
        if collection_name not in self.collections:
            print(f"[Database_Writer] \n [WARNING] \n Colección no encontrada: {collection_name}")
            return
        
        collection = self.collections[collection_name]

        document = {k: v for k, v in data.items() if k != "collection"}

        result = await collection.insert_one(document)
        print(f"[Database_Writer] Documento insertado con ID: {result.inserted_id}")