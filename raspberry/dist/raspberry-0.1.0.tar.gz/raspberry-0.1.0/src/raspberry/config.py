class StaticConfig:
    TANK_TOPIC = "invernadero/tanque"
    MANOMETER_TOPIC = "invernadero/manometro"
    PUMP_TOPIC = "invernadero/bomba"
    ENVIRONMENT_TOPIC = "application/b15867e8-a061-49d9-893b-c73112deb1a4/device/+/event/up"
    SOIL_TOPIC = "application/3d192c70-c2df-4b6d-9464-ae69106686fa/device/+/event/up"
    