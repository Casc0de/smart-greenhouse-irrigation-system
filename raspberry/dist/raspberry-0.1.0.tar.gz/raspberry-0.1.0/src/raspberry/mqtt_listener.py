class MQTTListener:
    def __init__(self, tank_data_queue, pressure_data_queue, mqtt_client = None):
        self.mqtt_client = mqtt_client

        self.tank_data_queue = tank_data_queue
        self.pressure_data_queue = pressure_data_queue
        #self.environment_data_queue = asyncio.Queue()      # TODO: para los datos ambientales del sensor LoRa
        #self.soil_data_queue = asyncio.Queue()             # TODO: para los datos del suelo del sensor LoRa
        

    async def recibir_dato(self, cliente_mqtt):
        self.mqtt_client = cliente_mqtt
        print("Escuchando en tópico: invernadero/#")
        # Suscribirse al tópico Invernadero_Edier
        await self.mqtt_client.subscribe("invernadero/#")

        async for mensaje in self.mqtt_client.messages:
            topic = mensaje.topic.value
            print(f"\n[MQTT_Listener] \n Mensaje recibido en tópico: {topic}\n")
            
            if topic.startswith("invernadero/tanque"):
                await self.tank_data_queue.put(mensaje)
            elif topic.startswith("invernadero/manometro"):
                await self.pressure_data_queue.put(mensaje)
            #elif topic.startswith("application/+/device/+/event/up"):
            #    await self.environment_data_queue.put(mensaje)
            #elif topic.startswith("application/+/device/+/event/up"):
            #    await self.soil_data_queue.put(mensaje)
